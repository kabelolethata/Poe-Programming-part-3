﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeAppPoe
{
    /// <summary>
    /// Interaction logic for DisplayRecipeDetailsWindow.xaml
    /// </summary>
    public partial class DisplayRecipeDetailsWindow : Window  // Ensure the class is correctly declared as public
    {
        private List<Recipe> recipes;

        public DisplayRecipeDetailsWindow(List<Recipe> recipes)  // Constructor
        {
            InitializeComponent();
            this.recipes = recipes;
        }

        private void DisplayDetails_Click(object sender, RoutedEventArgs e)  // Method to handle display details click
        {
            string recipeName = RecipeNameTextBox.Text;
            Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);

            if (recipe != null)
            {
                RecipeDetailsTextBlock.Text = $"Recipe Name: {recipe.Name}\n\nIngredients:\n";
                foreach (var ingredient in recipe.Ingredients)
                {
                    RecipeDetailsTextBlock.Text += $"- {ingredient}\n";
                }
                RecipeDetailsTextBlock.Text += "\nSteps:\n";
                for (int i = 0; i < recipe.Steps.Count; i++)
                {
                    RecipeDetailsTextBlock.Text += $"{i + 1}. {recipe.Steps[i].Description}\n";
                }

                double totalCalories = recipe.TotalCalories();
                RecipeDetailsTextBlock.Text += $"\nTotal Calories: {totalCalories}";

                if (totalCalories > 300)
                {
                    RecipeDetailsTextBlock.Text += "\nWarning: Total calories exceed 300!";
                }
            }
            else
            {
                MessageBox.Show($"Recipe '{recipeName}' not found.");
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)  // Method to handle close button click
        {
            this.Close();
        }
    }
}

