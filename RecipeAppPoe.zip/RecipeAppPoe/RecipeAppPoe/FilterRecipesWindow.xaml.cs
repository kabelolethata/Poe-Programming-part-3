﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeAppPoe
{
    /// <summary>
    /// Interaction logic for FilterRecipesWindow.xaml
    /// </summary>
    public partial class FilterRecipesWindow : Window
    {
        private List<Recipe> recipes;

        public FilterRecipesWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
        }

        private void Filter_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = IngredientTextBox.Text.ToLower();
            string foodGroup = FoodGroupTextBox.Text.ToLower();
            string maxCaloriesText = MaxCaloriesTextBox.Text;
            double maxCalories = string.IsNullOrWhiteSpace(maxCaloriesText) ? double.MaxValue : double.Parse(maxCaloriesText);

            var filteredRecipes = recipes.Where(r =>
                (string.IsNullOrWhiteSpace(ingredient) || r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient))) &&
                (string.IsNullOrWhiteSpace(foodGroup) || r.Ingredients.Any(i => i.FoodGroup.ToLower().Contains(foodGroup))) &&
                r.TotalCalories() <= maxCalories).OrderBy(r => r.Name);

            FilteredRecipesListBox.Items.Clear();
            foreach (var recipe in filteredRecipes)
            {
                FilteredRecipesListBox.Items.Add(recipe.Name);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

