﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace RecipeAppPoe
{
    /// <summary>
    /// Interaction logic for EnterRecipeWindow.xaml
    /// </summary>
    using System;
    using System.Collections.Generic;
    using System.Windows;

    namespace RecipeAppPoe
    {
        public partial class EnterRecipeWindow : Window
        {
            private List<Recipe> recipes;
            private List<string> recipeNames;
            private List<string> ingredientNames;
            private List<string> ingredientQuantities;
            private List<string> ingredientUnits;
            private List<string> ingredientCalories;
            private List<string> ingredientFoodGroups;

            public EnterRecipeWindow(List<Recipe> recipes)
            {
                InitializeComponent();
                this.recipes = recipes;
                recipeNames = new List<string>();
                ingredientNames = new List<string>();
                ingredientQuantities = new List<string>();
                ingredientUnits = new List<string>();
                ingredientCalories = new List<string>();
                ingredientFoodGroups = new List<string>();
            }

            private void AddIngredients_Click(object sender, RoutedEventArgs e)
            {
                int numIngredients;
                if (int.TryParse(NumIngredientsTextBox.Text, out numIngredients))
                {
                    IngredientsWindow ingredientsWindow = new IngredientsWindow(numIngredients);
                    ingredientsWindow.ShowDialog();

                    if (ingredientsWindow.Ingredients != null)
                    {
                        var ingredients = ingredientsWindow.Ingredients;
                        int numSteps;
                        if (int.TryParse(NumStepsTextBox.Text, out numSteps))
                        {
                            List<Step> steps = new List<Step>();
                            StepsWindow stepsWindow = new StepsWindow(numSteps);
                            stepsWindow.ShowDialog();

                            if (stepsWindow.Steps != null)
                            {
                                steps = stepsWindow.Steps;
                                Recipe recipe = new Recipe(RecipeNameTextBox.Text, ingredients, steps);
                                recipes.Add(recipe);
                                SaveRecipe(recipe);
                                MessageBox.Show("Recipe details added successfully.");
                            }
                            else
                            {
                                MessageBox.Show("No steps were added.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid number of steps.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No ingredients were added.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid number of ingredients.");
                }
            }

            private void Submit_Click(object sender, RoutedEventArgs e)
            {
                this.Close();
            }

            public void SaveRecipe(Recipe recipe)
            {
                recipeNames.Add(recipe.Name);
                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredientNames.Add(ingredient.Name);
                    ingredientQuantities.Add(ingredient.Quantity.ToString());
                    ingredientUnits.Add(ingredient.Unit);
                    ingredientCalories.Add(ingredient.Calories.ToString());
                    ingredientFoodGroups.Add(ingredient.FoodGroup);
                }
            }

            public string DisplayRecipes()
            {
                string message = "";
                for (int count = 0; count < recipeNames.Count; count++)
                {
                    message += "Recipe name: " + recipeNames[count] + "\n";
                    message += "Ingredient name: " + ingredientNames[count] + "\n";
                    message += "Ingredient quantity: " + ingredientQuantities[count] + "\n";
                    message += "Ingredient unit: " + ingredientUnits[count] + "\n";
                    message += "Ingredient calories: " + ingredientCalories[count] + "\n";
                    message += "Ingredient food group: " + ingredientFoodGroups[count] + "\n\n";
                }

                return message;
            }
        }
    }
}