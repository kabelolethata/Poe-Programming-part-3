﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeAppPoe
{
    /// <summary>
    /// Interaction logic for ScaleRecipeWindow.xaml
    /// </summary>
    public partial class ScaleRecipeWindow : Window
    {
        private List<Recipe> recipes;
        public ScaleRecipeWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;

        }
        private void Scale_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;
            double scaleFactor;
            if (double.TryParse(ScalingFactorTextBox.Text, out scaleFactor))
            {
                Recipe recipeToScale = recipes.FirstOrDefault(r => r.Name == recipeName);
                if (recipeToScale != null)
                {
                    recipeToScale.ScaleRecipe(scaleFactor);
                    MessageBox.Show($"Recipe {recipeName} scaled successfully.");
                }
                else
                {
                    MessageBox.Show($"Recipe {recipeName} not found.");
                }
            }
            else
            {
                MessageBox.Show("Invalid scaling factor.");
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
    

