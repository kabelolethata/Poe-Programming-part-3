﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace RecipeAppPoe
{
    public partial class IngredientsWindow : Window
    {
        public List<Ingredient> Ingredients { get; private set; }

        public IngredientsWindow(int numIngredients)
        {
            InitializeComponent();
            Ingredients = new List<Ingredient>();
            CreateIngredientFields(numIngredients);
        }

        private void CreateIngredientFields(int numIngredients)
        {
            for (int i = 0; i < numIngredients; i++)
            {
                StackPanel ingredientPanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(10) };

                TextBox nameTextBox = new TextBox { Width = 100, Text = "Name" };
                nameTextBox.GotFocus += TextBox_GotFocus;
                ingredientPanel.Children.Add(nameTextBox);

                TextBox quantityTextBox = new TextBox { Width = 50, Text = "Qty" };
                quantityTextBox.GotFocus += TextBox_GotFocus;
                ingredientPanel.Children.Add(quantityTextBox);

                TextBox unitTextBox = new TextBox { Width = 50, Text = "Unit" };
                unitTextBox.GotFocus += TextBox_GotFocus;
                ingredientPanel.Children.Add(unitTextBox);

                TextBox caloriesTextBox = new TextBox { Width = 50, Text = "Calories" };
                caloriesTextBox.GotFocus += TextBox_GotFocus;
                ingredientPanel.Children.Add(caloriesTextBox);

                TextBox foodGroupTextBox = new TextBox { Width = 100, Text = "Food Group" };
                foodGroupTextBox.GotFocus += TextBox_GotFocus;
                ingredientPanel.Children.Add(foodGroupTextBox);

                IngredientsItemsControl.Items.Add(ingredientPanel);
            }
        }

        private void SaveIngredients_Click(object sender, RoutedEventArgs e)
        {
            Ingredients.Clear();
            foreach (StackPanel panel in IngredientsItemsControl.Items)
            {
                string name = (panel.Children[0] as TextBox).Text;
                double quantity = double.Parse((panel.Children[1] as TextBox).Text);
                string unit = (panel.Children[2] as TextBox).Text;
                double calories = double.Parse((panel.Children[3] as TextBox).Text);
                string foodGroup = (panel.Children[4] as TextBox).Text;

                Ingredients.Add(new Ingredient(name, quantity, unit, calories, foodGroup));
            }
            this.DialogResult = true;
            this.Close();
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.Text = string.Empty;
        }
    }

    public class Ingredients
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }

        public Ingredients(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }
}
