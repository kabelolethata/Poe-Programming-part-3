﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RecipeAppPoe
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void EnterRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            EnterRecipeWindow enterRecipeWindow = new EnterRecipeWindow(recipes);
            enterRecipeWindow.ShowDialog();
        }

        private void DisplayListOfRecipes_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipesWindow displayRecipesWindow = new DisplayRecipesWindow(recipes);
            displayRecipesWindow.ShowDialog();
        }

        private void DisplayRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipeDetailsWindow displayRecipeDetailsWindow = new DisplayRecipeDetailsWindow(recipes);
            displayRecipeDetailsWindow.ShowDialog();
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            ScaleRecipeWindow scaleRecipeWindow = new ScaleRecipeWindow(recipes);
            scaleRecipeWindow.ShowDialog();
        }

        private void ResetQuantities_Click(object sender, RoutedEventArgs e)
        {
            foreach (var recipe in recipes)
            {
                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredient.ResetQuantity();
                }
            }
            MessageBox.Show("All quantities reset to default.");
        }

        private void ClearAllData_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear();
            MessageBox.Show("All data cleared.");
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        public Recipe(string name, List<Ingredient> ingredients, List<Step> steps)
        {
            Name = name;
            Ingredients = ingredients;
            Steps = steps;
        }

        public double TotalCalories()
        {
            return Ingredients.Sum(i => i.Calories);
        }

        public void ScaleRecipe(double scaleFactor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= scaleFactor;
            }
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }

        private double defaultQuantity;

        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;

            // Store the initial quantity as the default
            defaultQuantity = quantity;
        }

        public void ResetQuantity()
        {
            Quantity = defaultQuantity;
        }

        public override string ToString()
        {
            return $"{Quantity} {Unit} of {Name} - {Calories} calories ({FoodGroup})";
        }
    }

    public class Step
    {
        public string Description { get; set; }

        public Step(string description)
        {
            Description = description;
        }

        public static string IdentifyFoodGroup(string ingredientName)
        {
            Dictionary<string, string> foodGroupMap = new Dictionary<string, string>()
            {
                { "apple", "Fruits" },
                { "broccoli", "Vegetables" },
                { "chicken", "Protein" },
                // Add more mappings as needed
            };

            if (foodGroupMap.ContainsKey(ingredientName.ToLower()))
            {
                return foodGroupMap[ingredientName.ToLower()];
            }
            else
            {
                return "Unknown";
            }
        }
    }
}
    
