﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Collections.Generic;
using System.Windows;

namespace RecipeAppPoe
{
    public partial class StepsWindow : Window
    {
        public List<Step> Steps { get; private set; }

        public StepsWindow(int numSteps)
        {
            InitializeComponent();
            Steps = new List<Step>();
            for (int i = 0; i < numSteps; i++)
            {
                TextBox stepTextBox = new TextBox
                {
                    PlaceholderText = $"Step {i + 1}",
                    Margin = new Thickness(10)
                };
                StepsItemsControl.Items.Add(stepTextBox);
            }
        }

        private void SaveSteps_Click(object sender, RoutedEventArgs e)
        {
            Steps.Clear();
            foreach (TextBox stepTextBox in StepsItemsControl.Items)
            {
                if (!string.IsNullOrWhiteSpace(stepTextBox.Text))
                {
                    Steps.Add(new Step(stepTextBox.Text));
                }
            }
            this.DialogResult = true;
            this.Close();
        }
    }
}

